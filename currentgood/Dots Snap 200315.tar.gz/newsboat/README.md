.newsboat
=========

My `newsboat` configuration.

Features
--------

 - Vim centric bindings
 - Bookmark script that follows redirects, removes GA cruft from urls and bookmarks to `~/.newsboat/bookmarks.txt`

Installation
------------

    $ cd
    $ git clone https://github.com/gpakosz/.newsboat.git
