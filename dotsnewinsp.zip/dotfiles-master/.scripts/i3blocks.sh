git clone https://github.com/vivien/i3blocks-contrib.git ~/.i3/i3scripts/
